# TAGP
Course material

survivor2 verifieert of er al een proces geregistreerd is en/of er al een named_table bestaat.
indien dat zo is worden die eerst verwijderd alvorens nieuwe ... 
